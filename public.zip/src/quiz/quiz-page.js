
function QuizPage() {
    return (
        <main>
            <h1>Quiz Page</h1>
            <p>This is the quiz page</p>
        </main>
    );
}

export default QuizPage;